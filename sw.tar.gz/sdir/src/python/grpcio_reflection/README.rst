gRPC Python Reflection package
==============================

Reference package for reflection in GRPC Python.

Supported Python Versions
-------------------------
Python >= 3.5

Deprecated Python Versions
--------------------------
Python == 2.7. Python 2.7 support will be removed on January 1, 2020.

Dependencies
------------

Depends on the `grpcio` package, available from PyPI via `pip install grpcio`.

